/**
 * @file hdb.h
 * libhdb - Hooli database library
 *
 * @author Jeff Shantz <jeff@csd.uwo.ca>
 * @copyright Copyright (C) 2015, Jeff Shantz.  All rights reserved.
 * @version 1.0.0
 * @date 2015-10-09
 */

#ifndef HDB_H
#define HDB_H

#include <stdbool.h>

/**
 * Connection to the Hooli database
 */
typedef void* hdb_connection;

/**
 * A record stored in the Hooli database
 */
typedef struct hdb_record {
  char* username;          /**< User owning the file */
  char* filename;          /**< Name of the file */
  char* checksum;          /**< Checksum of the file's contents */
  struct hdb_record* next; /**< Pointer to next hdb_record in a linked list */
} hdb_record;

/**
 * Connect to the specified Hooli database server.
 * @see hdb_disconnect()
 * @param db_server Hostname of the database server
 * @return The initialized connection or `NULL`, if an error occurs.
 */
hdb_connection* hdb_connect(const char* db_server);

/**
 * Disconnect from the Hooli database server.
 * @see hdb_connect()
 * @param con A connection to a Hooli database server
 */
void hdb_disconnect(hdb_connection* con);

/**
 * Authenticate a user by password.  If successful, generates and returns
 * a unique 16-byte token that sent in all subsequent requests.
 * @param con A connection to a Hooli database server
 * @param username Username to authenticate
 * @param password Password to authenticate
 * @return A unique, 16-byte token if authentication is successful; otherwise, returns `NULL`.
 */
char* hdb_authenticate(hdb_connection* con, const char* username, const char* password);

/**
 * Verify an authenticate token to ensure it is valid.
 * @param con A connection to a Hooli database server
 * @param token The authentication token to verify
 * @return The username associated with the token, if it is valid; otherwise, returns `NULL`.
 */
char* hdb_verify_token(hdb_connection* con, const char* token);

/**
 * Store a file record in the Hooli database.
 * @see hdb_remove_file()
 * @param con A connection to a Hooli database server
 * @param record The record to store
 */
void hdb_store_file(hdb_connection* con, hdb_record* record);

/**
 * Remove a file record from the Hooli database.
 * @see hdb_store_file()
 * @param con A connection to a Hooli database server
 * @param username Username associated with the file
 * @param filename Name of the file to remove
 * @return `1`, if the file was removed successfully; `0` otherwise.
 */
int hdb_remove_file(hdb_connection* con, const char* username, const char* filename);

/**
 * Return the checksum for a given user's file stored in the Hooli database.
 * @param con A connection to a Hooli database server
 * @param username Username associated with the file
 * @param filename Name of the file
 * @return The checksum of the file.  If the file does not exist, `NULL` is returned.
 */
char* hdb_file_checksum(hdb_connection* con, const char* username, const char* filename);

/**
 * Get the number of files stored in the Hooli database for the specified user.
 * @param con A connection to a Hooli database server
 * @param username Username for which to retrieve a file count
 * @return The number of files stored in the database for the user.
 */
int hdb_file_count(hdb_connection* con, const char* username);

/**
 * Check whether or not the specified user exists.
 * @param con A connection to a Hooli database server
 * @param username Username to check
 * @return `true`, if the user has at least one file stored in the database; `false` otherwise.
 */
bool hdb_user_exists(hdb_connection* con, const char* username);

/**
 * Check whether or not the specified file exists.
 * @param con A connection to a Hooli database server
 * @param username Username associated with the file
 * @param filename Name of the file
 * @return `true`, if the user has the specified file stored in the database; `false` otherwise.
 */
bool hdb_file_exists(hdb_connection* con, const char* username, const char* filename);

/**
 * Obtain a linked list of all of the specified user's file records.
 * @see hdb_free_result()
 * @param con A connection to a Hooli database server
 * @param username Username for which to obtain a file list
 * @return A linked list of all of the user's file records.
 */
hdb_record* hdb_user_files(hdb_connection* con, const char* username);

/**
 * Free the linked list returned by hdb_user_files().
 * @see hdb_user_files()
 * @param record The linked list to free
 */
void hdb_free_result(hdb_record* record);

/**
 * Delete the specified user and all of his/her file records from the database.
 * @param con A connection to a Hooli database server
 * @param username Username to delete
 * @return `1`, if the user was deleted; `0` if the user was not found.
 */
int hdb_delete_user(hdb_connection* con, const char* username);

#endif

