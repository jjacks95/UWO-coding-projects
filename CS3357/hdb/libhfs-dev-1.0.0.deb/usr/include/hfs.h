/**
 * @file hfs.h
 * libhdb - Hooli file system library
 *
 * @author Jeff Shantz <jeff@csd.uwo.ca>
 * @copyright Copyright (C) 2015, Jeff Shantz.  All rights reserved.
 * @version 1.0.0
 * @date 2015-10-08
 */

#ifndef HFS_H
#define HFS_H

/**
 * An entry in the file system.
 */
typedef struct hfs_entry {
  char* rel_path;         /**< Path of the file relative to the root */
  char* abs_path;         /**< Absolute path of the file */
  int crc32;              /**< CRC-32 checksum of the file's contents */
  struct hfs_entry* next; /**< Pointer to the next entry in the list */
} hfs_entry;

/**
 * Retrieve a linked list of files in the directory tree rooted at `root_path`.
 *                                                                             
 * If one or more files/directories cannot be traversed, hfs_get_files()
 * prints a warning to STDERR, but continues scanning the directory tree.                       
 *                                                                             
 * If a fatal error occurs, it prints an error to STDERR and returns NULL.     
 *                                                                             
 * Note that, for each entry in the linked list, the `abs_path` member is        
 * dynamically allocated and must be released with free(3).  Additionally,     
 * the returned pointer itself is dynamically allocated and must also         
 * be released.  The `rel_path` pointer, however, is simply a pointer into       
 * `abs_path`, so it should not be freed.                                        
 *
 * @param root_path Root of the directory hierarchy to scan
 * @return A pointer to the first hfs_entry in a linked list; if an error occurs, returns NULL.
 */
hfs_entry* hfs_get_files(char* root_path);

#endif
